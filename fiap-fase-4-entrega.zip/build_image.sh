#!/usr/bin/env bash
set -e errexit
docker build -t fiap/fiap-api-produtos:1 .