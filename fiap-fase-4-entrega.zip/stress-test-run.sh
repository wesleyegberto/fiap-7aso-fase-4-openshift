#!/usr/bin/env bash
set -e errexit
k6 run stress-test-k6.js